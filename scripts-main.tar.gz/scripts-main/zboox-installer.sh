#!/bin/bash
#
#
#   sSSs   .S       S.    .S_SsS_S.     sSSs  
#  d%%SP  .SS       SS.  .SS~S*S~SS.   d%%SP  
# d%S'    S%S       S%S  S%S `Y' S%S  d%S'    
# S%|     S%S       S%S  S%S     S%S  S%S     
# S&S     S&S       S&S  S%S     S%S  S&S     
# Y&Ss    S&S       S&S  S&S     S&S  S&S_Ss  
# `S&&S   S&S       S&S  S&S     S&S  S&S~SP  
#   `S*S  S&S       S&S  S&S     S&S  S&S     
#    l*S  S*b       d*S  S*S     S*S  S*b     
#   .S*P  S*S.     .S*S  S*S     S*S  S*S.    
# sSS*S    SSSbs_sdSSS   S*S     S*S   SSSbs  
# YSS'      YSSP~YSSY    SSS     S*S    YSSP  
#                                SP           
#                                Y            
#
# DESENVOLVIDO_POR="SUMÉ Tecnologia" 
# LICENCIADO_PARA="MDOTTI"
# DESCRIÇÃO: 
#    Este script tem como objetivo realizar a instalação do sistema ZBOOX
#    em qualquer máquina que as imagens DOCKER estejam previamente instaladas
#    ou onde é possível acessar as imagens no GITLAB MDOTTI. 
# DEPENDÊNCIA:
#    - BASH 4.0 ou superior

VERSAO=1.21

# Changelog
# 1.0 - Versão inicial
# 1.1 - Ajustando diretorio config
# 1.2 - Corrigindo BUGs do docker compose 
# 1.3 - Corrigindo BUGs gerais
# 1.4 - Adicionando de atualizar AWS CLI
# 1.5 - Corrigindo BUG da chave SSH
# 1.6 - Adicionando cluster mais ajuste do docker swarm
# 1.7 - Adicionando nova função swarm leave. correção de bugs
# 1.8 - Adicionando node role para zboox GUI e DB
# 1.9 - Adicionando ENV HOST Cluster URL
# 1.9.1 - Adicionando condição de restart ao syscom
# 1.9.2 - Liberando uso do -v sem permissão de ROOT
# 1.10 - Adicionando stop container ao inicar o cluster e limpeza|validação /usr/local/zboox
# 1.10.1 - Corrigindo bug ao criar a pasta /home/mdotti
# 1.11 - Adicionando opção para executar sem pedir senha para o SUDO
# 1.11.1 - Corrigindo a internet a qual o SWARM precisa iniciar
# 1.12 - Adicionando opção de atualização das imagens
# 1.12.1 - Corrigindo BUGs na atualizacao na imagem e formatacao na tela
# 1.12.2 - Corrigindo BUG de remove e update services
# 1.12.3 - Ajustando para o apache pegar o IP mais atual todas as vezes que o instalador for executado. 
# 1.13 - Adicionando RCLONE de dependencia.
# 1.14 - Adicionado suporte para o NextCloud
# 1.14.1 - Removendo APACHE
# 1.15 - Adicionando suporte ao GRPC
# 1.16 - Adicionando suporte a versao de DEV
# 1.17 - Adicionando porta GRPC WEB
# 1.18 - Adicionando persistencia no BD postgres
# 1.19 - Adidionando env para active directory
# 1.20 - Adidionando env para user e password xml default
# 1.21 - Adicionando a variavel IP_HOST para o XML download 


# Coletando variaveis de ambiente
imageTag=latest
ipHost=$(ip addr show mgmt 2>/dev/null | grep "inet" | awk '{print $2}' | cut -d/ -f1 | head -1)
[ -z ${ipHost} ] && ipHost=$(ip addr show | grep "inet" | grep -v 127.0.0.1 | awk '{print $2}' | cut -d/ -f1 | head -1)
logFile=/usr/local/zboox/log/$(date +"%Y%m%d%H%M%S").zboox.log
runningUser=$(whoami)

parserArgumentos(){
    # Função para parsear os argumentos passados para o script
    if [[ $# -eq 0 ]]; then
        echo "Nenhuma opção foi passada. Use -h ou --help para obter ajuda."
        exit 1
    fi
    imageTag=latest
    argPass=""
    argInstall=0
    argRun=0
    argStop=0
    argLeave=0
    otherOptionsCount=0
      while [[ "$#" -gt 0 ]]; do
        case $1 in
            -h|--help)
              echo "Script de instalação do sistema ZBOOX"
              echo "Uso: $0 [OPÇÃO]"
              echo "Opções:"
              echo "  -h, --help          Exibir esta mensagem de ajuda"
              echo "  -v, --version       Exibir a versão do script"
              echo "  -p, --password      Recebe a senha do SUDO"
              echo "  -r, --run           Iniciar o sistema ZBOOX"
              echo "  -u, --update        Atualizar o sistema ZBOOX"
              echo "  --dev               Instala a versão de desenvolvimento"
              echo "  -s, --stop          Parar o sistema ZBOOX"
              echo "  -l, --leave         Sair do cluster"
              ;;
            -v|--version)
              echo "$0 $VERSAO"
              exit 0
              ;;
            -p|--password)
              ((otherOptionsCount++))
              if [[ -n "$argPass" ]]; then
                echo "A senha já foi especificada."
                exit 1
              fi
              argPass=$2
              shift
              ;;
            -i|--install)
              ((otherOptionsCount++))
              if [[ "$otherOptionsCount" -gt 1 ]]; then
                echo "Somente uma opção além de --password é permitida."
                exit 1
              fi
              argInstall=1
              ;;
            -r|--run)
              ((otherOptionsCount++))
              if [[ "$otherOptionsCount" -gt 1 ]]; then
                echo "Somente uma opção além de --password é permitida."
                exit 1
              fi
              argRun=1
              ;;
            -u|--update)
              ((otherOptionsCount++))
              if [[ "$otherOptionsCount" -gt 1 ]]; then
                echo "Somente uma opção além de --password é permitida."
                exit 1
              fi
              argUpdate=1
              ;;
            --dev)
              ((otherOptionsCount++))
              imageTag=dev
              argDevTag=1
              ;;
            -s|--stop)
              ((otherOptionsCount++))
              if [[ "$otherOptionsCount" -gt 1 ]]; then
                echo "Somente uma opção além de --password é permitida."
                exit 1
              fi
              argStop=1
              ;;
            -l|--leave)
              ((otherOptionsCount++))
              if [[ "$otherOptionsCount" -gt 1 ]]; then
                echo "Somente uma opção além de --password é permitida."
                exit 1
              fi
              argLeave=1
              ;;
            *)
              echo "Opção inválida: $1"
              exit 1
              ;;
        esac
        shift
      done

  if [[ "$argDevTag" -eq 1 ]]; then
      echo -e "### Configurando a TAG de [\033[0;31m DEV \033[0m]###"
  fi
  
  if [[ "$argInstall" -eq 1 ]]; then
      adicionaSUDOTemp
      logarMensagem "### Iniciando a INSTALAÇÃO ###"
      clearZbooxFolder
      validarDependencia 1
      instalarSistema
      removeSUDOTemp
  elif [[ "$argRun" -eq 1 ]]; then
      adicionaSUDOTemp
      logarMensagem "### Iniciando a INSTALAÇÃO ###"
      clearZbooxFolder
      validarDependencia 1
      instalarSistema
      logarMensagem "### Iniciando o SISTEMA ZBOOX ###"
      validationZbooxFiles
      iniciarSistema
      removeSUDOTemp
  elif [[ "$argUpdate" -eq 1 ]]; then
      excluded_service="zboox_system_db_zboox"
      services=$(docker service ls --format "{{.Name}}")
      adicionaSUDOTemp
      logarMensagem "### Atualizando o SISTEMA ZBOOX ###"
      atualizarImagens
      updateSistema
      removeSUDOTemp
  elif [[ "$argStop" -eq 1 ]]; then
      adicionaSUDOTemp
      logarMensagem "### Parando o SISTEMA ZBOOX ###"
      pararSistema
      removeSUDOTemp
  elif [[ "$argLeave" -eq 1 ]]; then
      adicionaSUDOTemp
      logarMensagem "### Saindo do Cluster ###"
      swarmLeave
      removeSUDOTemp
  else
      echo "Nenhuma ação foi especificada."
      exit 1
  fi
}

logarMensagem(){
   # Função para log de mensagens
    local message=$1
    local timestamp
    timestamp=$(date +"%Y-%m-%d %H:%M:%S")
    if ! [ -d /usr/local/zboox/log ]; then
        mkdir -p /usr/local/zboox/log 2> /dev/null
        if [ $? -ne 0 ]; then
            echo "$timestamp Falha ao acessar o diretório de log em /usr/local/zboox/log"
            echo "$timestamp Verifique se o usuário $(whoami) tem permissão de acesso"
            exit 1
        fi
    fi 
    if ! [ -f ${logFile} ]; then
        touch ${logFile}
        if [ $? -ne 0 ]; then
            echo "$timestamp Falha ao acessar o arquivo de log em ${logFile}"
            echo "$timestamp Verifique se o usuário $(whoami) tem permissão de acesso"
            exit 1
        fi
    fi
    echo -e "$timestamp $message" | tee -a ${logFile}
}

adicionaSUDOTemp(){
    local validaSUDO
    local validarROOT
    validarSUDO=$(grep -c "mdotti ALL=(ALL) NOPASSWD: ALL" /etc/sudoers.d/zboox)
    validarROOT=$(whoami)
    if [ "${runningUser}" == "root" ] ; then
        logarMensagem "O script não deve ser executado com permissões de root"
        logarMensagem "Crie um usuario, idealmente MDOTTI e inicie novamente"
        exit 1
    fi

    [ "${validarROOT}" == "root" ] && return 0    

    if [ "${validarSUDO}" -eq 0 ] ; then
      echo -e "-- Configurando acesso privilegiado temporário"
      if [ -z $argPass ]; then
        echo -e "-- Digite a senha do usuário ROOT:"
        su - root -c 'echo "mdotti ALL=(ALL) NOPASSWD: ALL" >> /etc/sudoers.d/zboox'
      else 
        echo $argPass | su - root -c 'echo "mdotti ALL=(ALL) NOPASSWD: ALL" >> /etc/sudoers.d/zboox'
      fi
      if [ $? -eq 0 ]; then
        echo -e "-- [\033[0;32m OK \033[0m] Acesso privilegiado temporário concedido"
      else 
        echo -e "-- [\033[0;31m NOK \033[0m] Falha a conceder acesso privilegiado temporário"
        exit 0
      fi
    fi

    if ! [ -d /usr/local/zboox ]; then 
        sudo mkdir -p /usr/local/zboox 2> /dev/null
        sudo chown mdotti:mdotti /usr/local/zboox
    fi

    ! [ -d /usr/local/zboox/log ] && mkdir -p /usr/local/zboox/log 2> /dev/null 
    if ! [ -d /usr/local/zboox/log ]; then
        logarMensagem "Falha na inicialização" 1
        logarMensagem "Erro ao criar o diretório de log em /usr/local/zboox/log" 1
        logarMensagem "Verifique as permissões de diretório." 1
        exit 1
    fi
}

removeSUDOTemp(){
    local validaSUDO
    validarSUDO=$(grep -c "mdotti ALL=(ALL) NOPASSWD: ALL" /etc/sudoers.d/zboox)
    if ! [ "$validarSUDO" -eq 0 ]; then
        logarMensagem "-- Removendo acesso privilegiado temporário"
        sudo sed -i '/mdotti ALL=(ALL) NOPASSWD: ALL/d' /etc/sudoers.d/zboox
        if [ $? -eq 0 ]; then
            logarMensagem "-- [\033[0;32m OK \033[0m] Acesso privilegiado temporário removido"
        else 
            logarMensagem "-- [\033[0;31m NOK \033[0m] Falha ao remover o acesso privilegiado temporário"
            exit 0
        fi
    fi
}

formatarProgresso(){
    local process_id=$1
    local progress=0
    local success=''
    local failure=''

    while true; do
        if ps -p $process_id > /dev/null; then
            progress=$((progress + 10))
            success="\033[0;32mProgresso: $progress%\033[0m"
        else
            exit_status=$?
            if [ $exit_status -eq 0 ]; then
                success="[\033[0;32m OK \033[0m]"
            else
                failure="[\033[0;31m NOK \033[0m]"
            fi
            break
        fi
        echo -e "\033[1A"  # Mover o cursor para a última linha
        echo -e "$success"  # Exibir sucesso em tempo real
        echo -e "$failure"  # Exibir falha em tempo real
        echo -e ""  # Limpar a linha de progresso anterior para exibir a próxima
        sleep 1
    done

    echo -e "\033[1A"  # Mover o cursor para a última linha 
}


validarDependencia(){
    local key
    local validaDependencia
    local instalar=$1
    declare -A dependenciasHashmap=(["docker-compose"]="docker-compose-plugin" 
                                    ["aws"]="awscli" 
                                    ["ssh"]="openssh"
                                    ["rclone"]="rclone"
                                    )
    logarMensagem "- Validando dependências"
    for key in "${!dependenciasHashmap[@]}"; do 
        if [ "${dependenciasHashmap[$key]}" == "awscli" ] ; then
            validaDependencia=$(aws --version | grep -c "aws-cli")
            if [ "$validaDependencia" -eq 0 ] ; then
                logarMensagem "-- [\033[0;31m NOK \033[0m] Dependência ${key} não encontrada."
                if [ "$instalar" -eq 1 ]; then
                    instalarDependencia "${dependenciasHashmap[$key]}"
                fi
            else
                logarMensagem "-- [\033[0;32m OK \033[0m] Dependência ${key} encontrada."
            fi
            continue
        fi
        validaDependencia=$(dpkg -l | grep -c "${dependenciasHashmap[$key]}")
        if [ "$validaDependencia" -eq 0 ] ; then
            logarMensagem "-- [\033[0;31m NOK \033[0m] Dependência ${key} não encontrada."
            if [ "$instalar" -eq 1 ]; then
                instalarDependencia "${dependenciasHashmap[$key]}"
            fi
        else
            logarMensagem "-- [\033[0;32m OK \033[0m] Dependência ${key} encontrada."
        fi
    done
    logarMensagem "- Validação de dependências finalizada"
}

clearZbooxFolder(){
  logarMensagem "--- [\033[1;33m -- \033[0m] Verificando se /usr/local/zboox/ existe..."
  if [ -d "/usr/local/zboox/" ]; then
    rm -rf /usr/local/zboox/ssh /usr/local/zboox/hosts /usr/local/zboox/zboox.conf /usr/local/zboox/docker-compose.yml  
    if [ -f "/usr/local/zboox/zboox.conf" ]; then
      logarMensagem "--- [\033[0;31m NOK \033[0m] Falha ao remover os conteúdos da pasta /usr/local/zboox/"
      exit 1
    else
      logarMensagem "--- [\033[0;32m OK \033[0m] Conteúdos da pasta /usr/local/zboox/ removidos com sucesso"
    fi
  else
    logarMensagem "--- [\033[1;33m -- \033[0m] A pasta /usr/local/zboox/ não existe"
  fi
}

validationZbooxFiles(){
  logarMensagem "--- [\033[0;32m OK \033[0m] Validando zboox /usr/local/zboox/*"
  if [ -d "/usr/local/zboox/" ]; then    
    if [ -d "/usr/local/zboox/ssh/" ]; then
      logarMensagem "--- [\033[0;32m OK \033[0m] /usr/local/zboox/ssh/"
    else
      logarMensagem "--- [\033[0;31m NOK \033[0m] /usr/local/zboox/ssh/ não existe ou não é um diretório."
      exit 1
    fi
    if [ -f "/usr/local/zboox/hosts" ]; then
      logarMensagem "--- [\033[0;32m OK \033[0m] /usr/local/zboox/hosts"
    else
      logarMensagem "--- [\033[0;31m NOK \033[0m] /usr/local/zboox/hosts não existe."
      exit 1
    fi
  else
    logarMensagem "--- [\033[1;33m -- \033[0m] /usr/local/zboox/ não existe."
  fi
  logarMensagem "--- [\033[0;32m OK \033[0m] Validação /usr/local/zboox/* concluida"
}

instalarDependencia(){
    local nomeDependencia
    nomeDependencia=$1
    adicionaSUDOTemp
    case $nomeDependencia in
        docker-compose-plugin)
            logarMensagem "--- Instalando Docker"
            sudo install -m 0755 -d /etc/apt/keyrings
            sudo curl -fsSL https://download.docker.com/linux/debian/gpg -o /etc/apt/keyrings/docker.asc
            sudo chmod a+r /etc/apt/keyrings/docker.asc
            echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/debian $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
            sudo apt purge docker-compose docker.io > /dev/null 2>&1
            sudo apt-get -q update > /dev/null 2>&1
            sudo apt-get -q install docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin > /dev/null 2>&1
            ;;
        apache2)
            logarMensagem "--- Desativando o Apache"
            sudo systemctl stop apache2 > /dev/null 2>&1
            sudo systemctl disable apache2 > /dev/null 2>&1
            logarMensagem "--- Desativado o Apache"
            ;;
        awscli)
            logarMensagem "--- Instalando AWS CLI"
            curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o /tmp/awscliv2.zip >/dev/null 2>&1
            unzip -u /tmp/awscliv2.zip -d /tmp/awscliv2 >/dev/null 2>&1
            if [ -d /usr/local/aws-cli ]; then
                sudo /tmp/awscliv2/aws/install --update >/dev/null 2>&1
                return 0
            fi
            sudo /tmp/awscliv2/aws/install >/dev/null 2>&1
            ;;
        openssh)
            logarMensagem "--- Instalando OpenSSH"
            apt-get -q update >/dev/null 2>&1
            apt-get -q install -y openssh >/dev/null 2>&1
            ;;
        rclone)
            logarMensagem "--- Instalando RCLONE"
            sudo apt-get -q update >/dev/null 2>&1
            sudo apt-get -q install -y rclone >/dev/null 2>&1
            ;;
        *)
            logarMensagem "--- Dependência não encontrada"
            ;;
    esac
}

configurarDependencia(){
    local statusDependencia
    adicionaSUDOTemp
    logarMensagem "-- Configurando dependência $1"
    case $1 in
        docker-compose-plugin)
            logarMensagem "--- [\033[1;33m -- \033[0m] Validando configuração do Docker Compose"
            statusDependencia=$(systemctl is-enabled docker)
            if ! [ "$statusDependencia" == "enabled" ]; then
                logarMensagem "--- Configurando Docker Compose"
                sudo systemctl enable docker > /dev/null 2>&1
                sudo systemctl start docker > /dev/null 2>&1
            fi
            logarMensagem "--- [\033[0;32m OK \033[0m] Docker Compose configurado"
            ;;
        sudoers)
            statusDependencia=$(sudo -l | grep -c "NOPASSWD: ALL")
            if [ "${statusDependencia}" -eq 0 ] ; then
                logarMensagem "--- [\033[0;31m NOK \033[0m] Usuário não tem permissão para alterar o arquivo sudoers"
                logarMensagem "--- [\033[0;31m NOK \033[0m] Necessario revisar as configurações do SUDOERS de forma manual"
                logarMensagem "--- [\033[0;31m NOK \033[0m] Permissões necessárias:
                    mdotti ALL=(ALL) NOPASSWD: /sbin/zpool status, /sbin/zfs list, /sbin/zfs list *, /sbin/zfs get *, /sbin/zfs clone *, /sbin/zfs snap *, /sbin/zfs destroy *
                    mdotti ALL=(ALL) NOPASSWD: /usr/local/sbin/storcli64 *
                    mdotti ALL=(ALL) NOPASSWD: /usr/bin/mkdir *, /usr/bin/tar *, /usr/bin/find *, /usr/bin/zcat * 
                    mdotti ALL=(ALL) NOPASSWD: /usr/bin/psql *, /usr/bin/pg_dumpall *, /usr/bin/gzip *
                    mdotti ALL=(ALL) NOPASSWD: /usr/bin/passwd *, /usr/sbin/usermod *
                    mdotti ALL=(ALL) NOPASSWD: /usr/bin/zboox *
                    mdotti ALL=(ALL) NOPASSWD: /usr/bin/cat /var/log/samba/audit.log, /usr/bin/tail /var/log/samba/audit.log, /usr/bin/tail -f /var/log/samba/audit.log"
                exit 1
            else 
                logarMensagem "--- [\033[1;33m -- \033[0m] Configurando sudoers"
                sudo sed -i '/\/usr\/bin\/cat *\|\/usr\/bin\/zcat *\|\/usr\/bin\/sed *\|\/sbin\/zpool status\|\/sbin\/zfs list\|\/sbin\/zfs get\|\/sbin\/zfs clone\|\/sbin\/zfs snap\|\/sbin\/zfs destroy/d' /etc/sudoers.d/zboox
                sudo sed -i '/\/usr\/bin\/zboox/d' /etc/sudoers.d/zboox
                sudo sed -i '/\/usr\/local\/sbin\/storcli64\|\/usr\/bin\/psql\|\/usr\/sbin\/usermod|\/usr\/bin\/passwd\|\/var\/log\/samba\/audit.log/d' /etc/sudoers.d/zboox
                sudo sed -i '/\/usr\/bin\/tail/d' /etc/sudoers.d/zboox
                sudo sed -i '/\/bin\/sed/d' /etc/sudoers.d/zboox
                echo "mdotti ALL=(ALL) NOPASSWD: /sbin/zpool status, /sbin/zfs list, /sbin/zfs list *, /sbin/zfs get *, /sbin/zfs clone *, /sbin/zfs snap *, /sbin/zfs destroy *" | sudo tee -a /etc/sudoers.d/zboox >/dev/null
                echo "mdotti ALL=(ALL) NOPASSWD: /usr/local/sbin/storcli64 *, /usr/bin/psql *, /usr/bin/passwd *, /usr/bin/cat /var/log/samba/audit.log, /usr/bin/tail /var/log/samba/audit.log, /usr/bin/tail -f /var/log/samba/audit.log, /usr/sbin/usermod" | sudo tee -a /etc/sudoers.d/zboox >/dev/null
                echo "mdotti ALL=(ALL) NOPASSWD: /usr/bin/mkdir *, /usr/bin/tar *, /usr/bin/find *, /usr/bin/zcat *" | sudo tee -a /etc/sudoers.d/zboox >/dev/null
                echo "mdotti ALL=(ALL) NOPASSWD: /usr/bin/zboox *" | sudo tee -a /etc/sudoers.d/zboox >/dev/null
                echo "mdotti ALL=(ALL) NOPASSWD: /usr/bin/tail" | sudo tee -a /etc/sudoers.d/zboox >/dev/null
                echo "mdotti ALL=(ALL) NOPASSWD: /usr/bin/sed" | sudo tee -a /etc/sudoers.d/zboox >/dev/null
                logarMensagem "--- [\033[0;32m OK \033[0m] Configuração do sudoers finalizada"
            fi
            ;;
        ssh)
            logarMensagem "--- [\033[1;33m -- \033[0m] Validando chaves SSH"
            [ -d /home/mdotti ] || sudo mkdir -p /home/mdotti 2>/dev/null
            sudo chown mdotti:mdotti /home/mdotti 2>/dev/null
            [ -d /home/mdotti/.ssh ] || mkdir -p /home/mdotti/.ssh
            sudo chmod 700 /home/mdotti/.ssh 2>/dev/null
            [ -s /home/mdotti/.ssh/authorized_keys2 ] || touch /home/mdotti/.ssh/authorized_keys2
            statusDependencia=$(grep -c "e20978648a80" /home/mdotti/.ssh/authorized_keys2)
            if [ "$statusDependencia" -eq 0 ]; then
                mkdir -p /home/mdotti/.ssh 2>/dev/null
                echo "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQDO13mptkLvkJ63F91R/Q1gGqCZ1pt/DNbMqUCy9GYjiURVX3vJUHZ67Ek4Faf6ZbsXnvUwCujOQ42790Zgt02XE6AiR2W9uaLoEpdK/QvBftveGggK9QqStu+cGwcNn0/GffjVftahJh5PNRRfhVAuMQz/cAXMDM0+5I47AnaguQzUK4oeoU4tKKQeJwz4woFLAuY6WuQBL0bnYQtW3WjOUqDcDjk7B+PKz6RPcL3i47+cj3/G2qZe78LFZMDRNUzDyL5DD583boMB1kC1ZY8punPjjt5gyzjGCWxym5jVZqZSP8GT/i/GAS+NnxYFHajHGIpMyOdNQOQ9VzKLdLhI0MWYLh6DhwrtA3o6ksXkaxbga1tIipwwQlXkm0r0XHW546qnJQAW94Sy705KB7GjnRhX6vOWp/0xXI0k2UVUNqTl4OqAkukxMK+cNi6U+I6E8c/HwAJXT8GYHqHd/peIH+E7DUBIRk0QEZjOM9vaw8vzEUAdn9JzYiCaxMGZWzs= root@e20978648a80" >> /home/mdotti/.ssh/authorized_keys2
            fi
            mkdir -p /usr/local/zboox/ssh >/dev/null 2>&1
            echo "-----BEGIN OPENSSH PRIVATE KEY-----
b3BlbnNzaC1rZXktdjEAAAAABG5vbmUAAAAEbm9uZQAAAAAAAAABAAABlwAAAAdzc2gtcn
NhAAAAAwEAAQAAAYEAztd5qbZC75CetxfdUf0NYBqgmdabfwzWzKlAsvRmI4lEVV97yVB2
euxJOBWn+mW7F571MArozkONu/dGYLdNlxOgIkdlvbmi6BKXSv0LwX7b3hoICvUKkrbvnB
sHDZ9Pxn341X7WoSYeTzUUX4VQLjEM/3AFzAzNPuSOOwJ2oLkM1CuKHqFOLSikHicM+MKB
SwLmOlrkAS9G52ELVt1ozlKg3A45Owfjys+kT3C94uO/nI9/xtqmXu/CxWTA0TVMw8i+Qw
+fN26DAdZAtWWPKbpz447eYMs4xglscpuY1WamUj/Bk/4vxgEvjZ8WBR2oxxiKTMjnTUDk
PVcyi3S4SNDFmC4eg4cK7QN6OpLF5GsW4GtbSIqcMEJV5JtK9Fx1ueOqpyUAFveEsu9OSg
exo50YV+rzlqf9MVyNJNlFVDak5eDqgJLpMTCvnDYulPiOhPHPx8ACV0/BmB6h3f6XiB/h
Ow1ASEZNEBGYzjPb2sPL8xFAHZ/Sc2IgmsTBmVs7AAAFiLmvlu25r5btAAAAB3NzaC1yc2
EAAAGBAM7Xeam2Qu+QnrcX3VH9DWAaoJnWm38M1sypQLL0ZiOJRFVfe8lQdnrsSTgVp/pl
uxee9TAK6M5Djbv3RmC3TZcToCJHZb25ougSl0r9C8F+294aCAr1CpK275wbBw2fT8Z9+N
V+1qEmHk81FF+FUC4xDP9wBcwMzT7kjjsCdqC5DNQrih6hTi0opB4nDPjCgUsC5jpa5AEv
RudhC1bdaM5SoNwOOTsH48rPpE9wveLjv5yPf8bapl7vwsVkwNE1TMPIvkMPnzdugwHWQL
Vljym6c+OO3mDLOMYJbHKbmNVmplI/wZP+L8YBL42fFgUdqMcYikzI501A5D1XMot0uEjQ
xZguHoOHCu0DejqSxeRrFuBrW0iKnDBCVeSbSvRcdbnjqqclABb3hLLvTkoHsaOdGFfq85
an/TFcjSTZRVQ2pOXg6oCS6TEwr5w2LpT4joTxz8fAAldPwZgeod3+l4gf4TsNQEhGTRAR
mM4z29rDy/MRQB2f0nNiIJrEwZlbOwAAAAMBAAEAAAGAC1GI+7Dm4o7hmWX2PuMxmJ9cZD
lYzyxUPZ3nKxyjtNtxLrVycfhein4dVyTGc+6eEkxh0tFpkFVBHZa0oPjm3LNM5NprVJ4G
IBTn6LsGVMUszKhUc+ULCGfM8+1vlO0G0dquZyd/dkoFeiEAjp7lXajUJM8Ws+X9qMkp3Y
U54JfcKL5JMCTJwQbcTRoYnPQu6pjIPb2uLwe+0DC5fpGXFbbHzN9VDCusk9bCuh8EWl9n
o3yt24bv6evMz8v3n16p29zVx7kyAi2ZmiTd/mJOJw4V6L2kfQGgJj9pgG3XIroGn2gXsP
HFpxN2GS+FyAZ3Dmi2BrdoKwdZ2cCV2wsfeJzsFDacEYmYmwHTJbhBeHT9pC2p2sUnz5Ey
+ByphJkY8nOJY3zO88vFVp40CFPOMBl9nbqhnW79ydRKRn7ppgp6RI7+qjzCVI3eD3Urj7
WrQXyljYTIEOvhMNaNRnGNeWJh+NzwG3E91+ookg4dmm7HdEHRI/Wa3jhhO5oN8xEBAAAA
wFG5zbFj9rF4Y+pvaHGXIiI4jdYP5Ab0SXRdXJ9MoQ7ob5VCKAC+NE3vfHAa5vBLlb3tng
KCp+jlNEtRiitQ7h2wx/5Ji8EyNz1QwgFTx5cyQjJa2y6iAcMDP4Uey4nLgplpq2f5ptHP
eYE345r2YbPubMaR1hqeiBYQXDXZ5DoaCBlX0cYkjf5eUo9WUSoexmBIWDzlVt9QwUEupv
hcjw2rTxcTeBAViTPqNRbfUuBe1jR4dyh7HWRVLp35iMQ8jgAAAMEA/GEsjzjOjsDA1NZG
jndssMB1KvFFRPRrIcwbLgnBGB3pLdq3Md1Qf+I3B8bE5MvgLLipy0JW1xrtqNsmf7JMAy
0LB8c9ttIBp4qkhBI+Ke4vQeo2ggifPRJuo9tUXTfrcZMwh0/N/lJPXLVJrGXnkkWKf1j+
8o5KiR0FWmQ49VDTb8F/yB1KK1apoYqODAqdF1qv8+tK3mcyX1LdNH9c27TY3dcbPRvY7e
9Xr1AiG91dIYZ4TqkPgVS1mfxtJvrbAAAAwQDRzxH2ypqL9m1z9EKjBbuEwwICYTLTAMo5
YnymLNtpMJgMBn84jr7aPDvdCkvUGFxqzTToP5vN5/BYqkTEdsQ0YlK0wjrcOryb8XaZGk
U+Gn+ZovIb9D2m4GgIJQWyhrfXjlrZLhPRYkepqv8rJKO/w8byF5onHmKuEHkHkpNEPRNM
iNXmP/6t5F6vyaWUfDbn1sXCqLG8NDP1FByx9Ng9MhkbI80SLR8/CVCGQK0staFEzvSzi/
WHoeeYAm/fnyEAAAARcm9vdEBlMjA5Nzg2NDhhODABAg==
-----END OPENSSH PRIVATE KEY-----" > /usr/local/zboox/ssh/id_rsa
            chmod 600 /usr/local/zboox/ssh/id_rsa
            echo "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQDO13mptkLvkJ63F91R/Q1gGqCZ1pt/DNbMqUCy9GYjiURVX3vJUHZ67Ek4Faf6ZbsXnvUwCujOQ42790Zgt02XE6AiR2W9uaLoEpdK/QvBftveGggK9QqStu+cGwcNn0/GffjVftahJh5PNRRfhVAuMQz/cAXMDM0+5I47AnaguQzUK4oeoU4tKKQeJwz4woFLAuY6WuQBL0bnYQtW3WjOUqDcDjk7B+PKz6RPcL3i47+cj3/G2qZe78LFZMDRNUzDyL5DD583boMB1kC1ZY8punPjjt5gyzjGCWxym5jVZqZSP8GT/i/GAS+NnxYFHajHGIpMyOdNQOQ9VzKLdLhI0MWYLh6DhwrtA3o6ksXkaxbga1tIipwwQlXkm0r0XHW546qnJQAW94Sy705KB7GjnRhX6vOWp/0xXI0k2UVUNqTl4OqAkukxMK+cNi6U+I6E8c/HwAJXT8GYHqHd/peIH+E7DUBIRk0QEZjOM9vaw8vzEUAdn9JzYiCaxMGZWzs= root@e20978648a80" > /usr/local/zboox/ssh/id_rsa.pub
            logarMensagem "--- [\033[0;32m OK \033[0m] Configuração das chaves SSH finalizada"
            ;;
        hosts)
            logarMensagem "--- [\033[1;33m -- \033[0m] Configurando hosts"
            mkdir -p /usr/local/zboox 2> /dev/null
            echo "${ipHost} zboox.mdotti" > /usr/local/zboox/hosts
            echo "${ipHost} db_zboox" >> /usr/local/zboox/hosts
            logarMensagem "--- [\033[0;32m OK \033[0m] Configuração do hosts finalizada"
            ;;
        docker)
            logarMensagem "--- [\033[1;33m -- \033[0m] Configurando do daemon do docker"
            if ! [ $(groups "$runningUser" | grep -q '\bdocker\b') ] ; then
                sudo usermod -aG docker "$runningUser"
                if [ $? -eq 0 ]; then
                    logarMensagem "--- [\033[0;32m OK \033[0m] Usuario no grupo docker"
                else
                    logarMensagem "--- [\033[0;31m NOK \033[0m] Falha ao adicionar no grupo docker"
                fi
            fi
            sudo systemctl restart docker
            logarMensagem "--- [\033[0;32m OK \033[0m] Configuração do daemon do docker finalizada"
            logarMensagem "--- [\033[1;33m -- \033[0m] Configurando Docker Compose"
            mkdir /usr/local/zboox/db_zboox 2> /dev/null
            chown -R "$runningUser" /usr/local/zboox/db_zboox 2>/dev/null
            echo "
networks:
  net_zboox:
    name: net_zboox
    driver: overlay
    attachable: true

services:
  db_zboox:
    container_name: db_zboox
    image: postgres:17
    restart: unless-stopped
    ports:
      - 5433:5432
    environment:
      - POSTGRES_PASSWORD=sume2024
      - TZ=America/Sao_Paulo
    networks:
      net_zboox:
        aliases:
          - db_zboox
    volumes:
      - /usr/local/zboox/db_zboox:/var/lib/postgresql/data
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U postgres"]
      interval: 5s
      timeout: 5s
      retries: 5
    deploy:
      restart_policy:
        condition: any
        delay: 5s
        max_attempts: 5
        window: 120s
      placement:
        constraints:
          - node.role == manager

  auth:
    container_name: auth
    tty: true
    depends_on:
      - db_zboox
    image: repo.mdotti.com/zboox/auth:${imageTag}
    env_file: zboox.conf
    restart: unless-stopped
    environment:
      - TZ=America/Sao_Paulo
    networks:
      net_zboox:
        aliases:
          - auth
    ports:
      - 3021:3000
    volumes:
      - /usr/local/zboox/ssh:/root/.ssh
      - /usr/local/zboox/hosts:/etc/hosts
      - /usr/local/zboox/zboox.conf:/app/zboox.conf
    deploy:
      restart_policy:
        condition: any
        delay: 5s
        max_attempts: 5
        window: 120s

  syscom:
    container_name: syscom
    image: repo.mdotti.com/zboox/syscom:${imageTag}
    tty: true
    depends_on: 
      - auth      
    env_file: zboox.conf
    restart: unless-stopped
    networks:
      net_zboox:
        aliases:
          - syscom
    ports:
      - 3022:3000
      - 3024:3024
      - 3025:3025
    volumes:
      - /usr/local/zboox/ssh:/root/.ssh
      - /usr/local/zboox/hosts:/etc/hosts
      - /usr/local/zboox/zboox.conf:/app/zboox.conf
    deploy:
      restart_policy:
        condition: any
        delay: 5s
        max_attempts: 5
        window: 120s

  zboox-gui:
    container_name: zboox-gui
    image: repo.mdotti.com/zboox/front:${imageTag}
    env_file: zboox.conf
    ports:
      - 1002:3000
    volumes:
      - /usr/local/zboox/zboox.conf:/app/zboox.conf
    restart: unless-stopped
    deploy:
      replicas: 1
      restart_policy:
        condition: on-failure
        delay: 5s
        max_attempts: 5
        window: 120s
      placement:
        constraints:
          - node.role == manager

  cluster:
    image: repo.mdotti.com/zboox/cluster:${imageTag}
    container_name: cluster
    volumes:
      - /usr/local/zboox/ssh:/root/.ssh
      - /usr/local/zboox/hosts:/etc/hosts
      - /usr/local/zboox/zboox.conf:/app/zboox.conf
    restart: unless-stopped
    ports:
      - 3023:8000
    env_file: zboox.conf
    deploy:
      restart_policy:
        condition: on-failure
        delay: 5s
        max_attempts: 5
        window: 120s
      placement:
        constraints:
          - node.role == manager
" | tee /usr/local/zboox/docker-compose.yml >/dev/null
                logarMensagem "--- [\033[0;32m OK \033[0m] Configuração do Docker Compose finalizada"   
                logarMensagem "--- [\033[1;33m -- \033[0m] Configurando variáveis de ambiente"
                echo "TZ=America/Sao_Paulo
AD_CLIENT=false
TIMEOUT=20000
REFRESH_SECONDS=2
DATABASE_URL=postgresql://postgres:sume2024@db_zboox:5433/mdotti
ZBOOX_CONNECTION=ssh -o StrictHostKeyChecking=no mdotti@zboox.mdotti
PASSWORD_SECRET=5UM3&MD0TT1
PORT=3000
WEB_PORT=1002
AUTH_PORT=3021
SYSCOM_PORT=3022
CLUSTER_PORT=3023
GRPC_PORT=3024
GRPC_WEB_PORT=3025
POSTGRES_PASSWORD="sume2024"
DEFAULT_USER="zboox_admin"
DEFAULT_PASSWORD="12345678"
DEFAULT_XML_USER="mdotti"
DEFAULT_XML_PASSWORD="5UM3@2025"
SALT_SECRET="SUMETecnologia2024"
JWT_SECRET=SUMETecnologia2024
X_TOKEN=skfjsdimJvb3gR5cCI6Ikaoenfgale6II1NiI
IP_HOST=${ipHost}
AUTH_API_URL=http://${ipHost}:3021
SYSCOM_API_URL=http://${ipHost}:3022
SYSCOM_WS_API_URL=ws://${ipHost}:3022
CLUSTER_API_URL=http://${ipHost}:3023
ZBOOX_BACKUP="zboox_backup"
ZBOOX_BACKUP_PATH="/zboox/zvol01/backup"
DEFAULT_XML_PASSWORD="5UM3@2025"
DEFAULT_XML_USER="mdotti"
NEXT_PUBLIC_WHATSAPP_NUMBER=5511966376272
                " | tee /usr/local/zboox/zboox.conf >/dev/null
            logarMensagem "--- [\033[0;32m OK \033[0m] Configuração das variáveis de ambiente finalizada"
            logarMensagem "--- [\033[1;33m -- \033[0m] Configurando daemon do docker"
            echo '{
    "insecure-registries" : ["gitlab.mdotti.com", "repo.mdotti.com"]
}' | sudo tee /etc/docker/daemon.json >/dev/null
            sudo systemctl restart docker
            logarMensagem "--- [\033[0;32m OK \033[0m] Configurando daemon do docker finalizada"
            ;;
        *)
            logarMensagem "--- Dependência não encontrada"
            ;;
    esac
}

iniciarSistema(){
    local validaImagem
    local imagemDocker
    logarMensagem  "-- [\033[1;33m -- \033[0m] Verificando a existência do arquivo docker-compose.yml"
    [ -s /usr/local/zboox/docker-compose.yml ] && logarMensagem "-- [\033[0;32m OK \033[0m] Arquivo docker-compose configurado" || configurarDependencia "docker"
    
    containers=$(docker ps -aq)
    if [ -n "${#containers}" ]; then
        logarMensagem  "--- [\033[1;33m -- \033[0m] Parando Serviços..."
        swarm_state=$(docker stop $containers 2>/dev/null)
        logarMensagem "--- [\033[0;32m OK \033[0m] Serviços parados com sucesso"
    fi

    logarMensagem  "-- [\033[1;33m -- \033[0m] Validando a existência das imagens"
    for imagemDocker in auth syscom front cluster; do
        validaImagem=$(docker image ls | grep -c "${imagemDocker}")
        if [ $validaImagem -eq 0 ]; then
            logarMensagem "-- [\033[0;31m NOK \033[0m] Imagem ${imagemDocker} não encontrada"
            docker pull repo.mdotti.com/zboox/${imagemDocker}:${imageTag}
            if [ $? -eq 0 ]; then
                logarMensagem "-- [\033[0;32m OK \033[0m] Imagem ${imagemDocker} baixada"
            else
                logarMensagem "-- [\033[0;31m NOK \033[0m] Falha ao baixar a imagem ${imagemDocker}"
            fi
        fi
    done

    swarm_state=$(docker info --format '{{.Swarm.LocalNodeState}}' 2>/dev/null)
    logarMensagem "-- [\033[1;33m -- \033[0m] Iniciando o Swarm"
    if [ "$swarm_state" == "inactive" ]; then
        swarm_init_output=$(docker swarm init --advertise-addr $ipHost:2377 2>&1)
        logarMensagem "-- [\033[0;32m OK \033[0m] Swarm inicializado com sucesso!"
    else
        logarMensagem "-- [\033[1;33m -- \033[0m] Modo docker swarm já está ativo!"
        logarMensagem "-- [\033[1;33m -- \033[0m] Use 'bash zboox-installer.sh --leave' se quiser sair do cluster atual e rode 'bash zboox-installer.sh --run' novamente"  
    fi

    logarMensagem "-- [\033[1;33m -- \033[0m] Iniciando o docker swarm stack"
    docker stack deploy -c /usr/local/zboox/docker-compose.yml zboox_system --resolve-image changed --prune > /dev/null 2>&1
    if [ $? -eq 0 ]; then
        logarMensagem "-- [\033[0;32m OK \033[0m] Docker swarm stack concluido"
    else
        logarMensagem "-- [\033[0;31m NOK \033[0m] Falha ao iniciar o swarm stack"
    fi
}

atualizarImagens(){
  logarMensagem "-- [\033[1;33m -- \033[0m] Atualizando imagens ZBOOX"
  for service in $services; do
    if [ "$service" == "$excluded_service" ]; then
      continue
    fi
    image=$(docker service inspect --format '{{index .Spec.TaskTemplate.ContainerSpec.Image}}' $service | sed 's/:.*//')
    logarMensagem "--- [\033[1;33m -- \033[0m] Atualizando imagem: $image:$imageTag"
    docker pull ${image}:$imageTag >/dev/null
    if [ $? -eq 0 ]; then
        logarMensagem "--- [\033[0;32m OK \033[0m] Atualizada imagem: $image:$imageTag"
    else
        logarMensagem "--- [\033[0;31m NOK \033[0m] Falha ao atualizar imagem $image:$imageTag"
    fi
  done
}

updateSistema(){
  logarMensagem "-- [\033[1;33m -- \033[0m] Atualizando servicos ZBOOX"
  for service in $services; do
    if [ "$service" == "$excluded_service" ]; then
      continue
    fi
    image=$(docker service inspect --format '{{index .Spec.TaskTemplate.ContainerSpec.Image}}' $service | sed 's/:.*//')
    logarMensagem "--- [\033[1;33m -- \033[0m] Atualizando: $service"
    docker service update --image "$image:${imageTag}" $service --force >/dev/null 2>&1
    if [ $? -eq 0 ]; then
        logarMensagem "--- [\033[0;32m OK \033[0m] Atualizado servico: $service"
    else
        logarMensagem "--- [\033[0;31m NOK \033[0m] Falha ao atualizar servico $service"
    fi
  done
}

pararSistema(){
  logarMensagem "-- [\033[1;33m -- \033[0m] Parando serviço ZBOOX"
  services=$(docker service ls --format "{{.Name}}")
  for service in $services; do
    logarMensagem "-- [\033[1;33m -- \033[0m] Parando serviço: $service"
    docker service rm $service >/dev/null 2>&1
    if [ $? -eq 0 ]; then
        logarMensagem "--- [\033[0;32m OK \033[0m] Serviço parado: $service"
    else
        logarMensagem "--- [\033[0;31m NOK \033[0m] Falha ao parar o serviço: $service"
    fi
  done
}

instalarSistema(){
    local process_id=$$
    local progress=0
    local success=''
    local failure=''
    declare -A dependenciasHashmap=(["docker-compose"]="docker-compose-plugin" 
                                    ["docker"]="docker"
                                    ["sudoers"]="sudoers"
                                    ["openssh"]="ssh"
                                    ["hosts"]="hosts"
                                    )
    logarMensagem "- Iniciando configuração do sistema ZBOOX"
    for key in "${!dependenciasHashmap[@]}"; do 
        configurarDependencia "${dependenciasHashmap[$key]}"
    done
    logarMensagem "- Configuração concluída com sucesso"
}

swarmLeave(){
    logarMensagem "-- [\033[1;33m -- \033[0m] Saindo do modo Swarm"
    swarm_state=$(docker info --format '{{.Swarm.LocalNodeState}}' 2>/dev/null)
    if [ "$swarm_state" == "active" ]; then
        docker swarm leave --force 2>/dev/null
    fi
    encontrarDockerVolume=$(docker volume ls | grep -c "zboox")
    if [ $encontrarDockerVolume -gt 0 ]; then
        docker volume rm $(docker volume ls | grep "zboox" | awk '{print $2}') >/dev/null 2>&1
    fi
    encontrarDockerContainer=$(docker container ls -a | grep -c "zboox")
    while [ $encontrarDockerContainer -gt 0 ]; do
      docker container rm $(docker container ls -a | grep "zboox" | awk '{print $1}') >/dev/null 2>&1
      encontrarDockerContainer=$(docker container ls -a | grep -c "zboox")
    done
    logarMensagem "-- [\033[0;32m OK \033[0m] Sainda do modo swarm concluida"
}

# Início do script

parserArgumentos $@

logarMensagem "### Script finalizado ###"
